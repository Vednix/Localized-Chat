# Localized-Chat
Localized chat for terraria

Makes chat pop up briefly above a player's head, and only sends it to other players within a config defined radius.
Setting the config value to 0 will result in no chat message being sent, just a pop up appearing.
Setting the config value to -1 will result in chat being global as normal, but with still with the pop up.

The config can be reloaded with the /reload command 

